name = input("Enter appliance name: ")
cost = float(input("Enter cost: "))

if cost > 1000:
    warranty = cost * 0.10
else:
    warranty = cost * 0.05

total = cost + warranty

print(f"Appliance: {name}")
print(f"Cost: ${cost:.2f}")
print(f"Warranty: ${warranty:.2f}")
print(f"Total: ${total:.2f}")